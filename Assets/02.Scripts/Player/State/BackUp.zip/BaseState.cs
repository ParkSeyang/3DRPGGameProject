using System;
using UnityEngine;

public abstract class BaseState
{
    public struct StateControllerParameter
    {
        public PlayerController playerController;
        public Transform effectPoint;
        public ParticleSystem swordEffect;
        public Animator playerAnimator;
        public Collider SwordCollider;
        public AnimEventReceiver AnimEventReceiver;
    }
    
    protected PlayerController PlayerController { get; private set; }
    protected Animator PlayerAnimator { get; private set; }

    public virtual void Initialize(StateControllerParameter parameter)
    {
        PlayerController = parameter.playerController;
        PlayerAnimator = parameter.playerAnimator;
    }

    public abstract void EnterState();

    public abstract void UpdateState();
    
    public abstract void ExitState();
    
}
