using UnityEngine;

public class IdleState : BaseState
{
    private const float WAIT_TIME = 3.0f;
    private float timer = 0.0f;
    
    public override void EnterState()
    {
        timer = 0.0f;
    }

    public override void UpdateState()
    {
        timer += Time.deltaTime;
        if (timer >= WAIT_TIME)
        {
            int randNum = Random.Range(0, 2);
            switch (randNum)
            {
                case 0:
                    PlayerController.ChangeState<ComboAttackState>();
                    break;
                case 1:
                    PlayerController.ChangeState<GuardState>();
                    break;
                default:
                    PlayerController.ChangeState<IdleState>();
                    break;
            }
        }

        if (Input.GetKeyDown(KeyCode.T))
        {
            PlayerController.ChangeState<DeadState>();
        }

    }
    
    public override void ExitState()
    {
    }
}
