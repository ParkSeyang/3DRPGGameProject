using UnityEngine;

public class DeadState : BaseState
{
    private static readonly int Dead = Animator.StringToHash("Dead");


    public override void EnterState()
    {
        PlayerAnimator.SetTrigger(Dead);
    }

    public override void UpdateState()
    {
        
    }

    public override void ExitState()
    {
        
    }
}
