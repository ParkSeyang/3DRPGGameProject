﻿using UnityEngine;
using System;
using System.Collections.Generic;
using UnityEngine.Serialization;
using Random = UnityEngine.Random;

public class PlayerController : MonoBehaviour
{

    public float WalkSpeed = 3.0f;
    public float RunSpeed = 6.0f;
    public float RotateSpeed = 10.0f;

    public Vector2 InputVector { get; private set; }
    public Vector3 MoveDirection { get; private set; }
    public CharacterController CharacterController { get; private set; }


    [SerializeField] private Transform effectPoint;
    [SerializeField] private Collider SwordCollider;
    [SerializeField] private ParticleSystem swordEffect;
    
    [SerializeField] private AnimEventReceiver AnimEventReciver;
    private Animator Animator { get; set; }
    private Dictionary<Type, BaseState> States { get; set; }
    private BaseState CurrentState { get; set; }
    private BaseState DefaultState { get; set; }

    private void Awake()
    {
        
        Animator = GetComponent<Animator>();
        SwordCollider.enabled = false;
        States = new Dictionary<Type, BaseState>();
        States.Add(typeof(IdleState), new IdleState());

        int randNum = Random.Range(0, 2);
        if (randNum == 0)
        {
            States.Add(typeof(ComboAttackState), new ComboAttackState());
        }
        else
        {
            States.Add(typeof(GuardState), new GuardState());
        }
        
        DefaultState = States[typeof(IdleState)];

        BaseState.StateControllerParameter param = new BaseState.StateControllerParameter();

        param.playerController = this;
        param.SwordCollider = SwordCollider;
        param.swordEffect = swordEffect;
        param.effectPoint = effectPoint;
        param.playerAnimator = Animator;
        param.AnimEventReceiver = AnimEventReciver;

        foreach (var state in States.Values)
        {
            state.Initialize(param);
        }
        
        ChangeState<IdleState>();
    }

    private void Update()
    {
        CurrentState.UpdateState();
    }

    public void ChangeState<T>() where T : BaseState
    {
        var prevState = CurrentState;
        prevState?.ExitState();

        CurrentState = DefaultState;
        if (States.ContainsKey(typeof(T)))
        {
            CurrentState = States[typeof(T)];
        }
        CurrentState.EnterState();
        Debug.Log($"{prevState?.GetType().Name} changed to {CurrentState.GetType().Name}");
    }

}
