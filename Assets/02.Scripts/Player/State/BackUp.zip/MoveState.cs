﻿using System;
using Unity.Profiling.LowLevel.Unsafe;
using UnityEngine;
public class MoveState : BaseState
{
    private float walkSpeed = 3.0f;
    private float runSpeed = 6.0f;
    private bool isMove = false;
    private AnimEventReceiver playerAnimreceiver;

    public override void EnterState()
    {

    }

    public override void UpdateState()
    {
        
    }

    public override void ExitState()
    {
       
    }

    public void OnMove()
    {
     
    }

}
