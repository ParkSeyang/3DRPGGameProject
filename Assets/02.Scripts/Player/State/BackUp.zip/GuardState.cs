﻿using System;
using System.Collections.Generic;
using UnityEngine;
public class GuardState : BaseState
{
    private Collider SwordCollider;
    private AnimEventReceiver receiver;
    // private bool isGuard = Input.GetKey(KeyCode.Mouse1);

    public override void Initialize(StateControllerParameter parameter)
    {
        base.Initialize(parameter);
        SwordCollider = parameter.SwordCollider;
        receiver = parameter.AnimEventReceiver;
    }

    public override void EnterState()
    {
        SwordCollider.enabled = true;
        PlayerAnimator.SetBool("IsGuard", true);

        receiver.OnAnimationTriggerReceived += OnTriggerAnim;
    }

    public override void UpdateState()
    {
        return;
    }
    

    public override void ExitState()
    {
        SwordCollider.enabled = false;
        receiver.OnAnimationTriggerReceived -= OnTriggerAnim;
    }

    private const string ATP_COLLIDER_ON = "Guard_Collider_ON";
    private const string ATP_COLLIDER_OFF = "Guard_Collider_Off";
    private const string ATP_ANIM_END = "Guard_End";

    public void OnTriggerAnim(string str)
    {
        switch (str)
        {
            case ATP_COLLIDER_ON:
                SwordCollider.enabled = true;
                break;
            case ATP_COLLIDER_OFF:
                SwordCollider.enabled = false;
                break;
            case ATP_ANIM_END :
                PlayerController.ChangeState<IdleState>();
                break;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        
    }
}
