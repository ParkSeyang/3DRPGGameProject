using System;
using UnityEngine;

public class ComboAttackState : BaseState
{
    private static readonly int ComboAttack = Animator.StringToHash("ComboAttack");
    private static readonly int IsAttack = Animator.StringToHash("IsAttack");

    private Collider SwordCollider;
    private Transform effectPoint;
    private ParticleSystem swordEffect;
    private AnimEventReceiver receiver;
    private bool isAttackAble = false;

    public override void Initialize(StateControllerParameter parameter)
    {
        base.Initialize(parameter);
        SwordCollider = parameter.SwordCollider;
        swordEffect = parameter.swordEffect;
        effectPoint = parameter.effectPoint;
        receiver = parameter.AnimEventReceiver;
    }

    

    public override void EnterState()
    {
        swordEffect.gameObject.SetActive(true);
        swordEffect.Play();
        isAttackAble = true;
        receiver.OnAnimationTriggerReceived += OnTriggerAnim;
        
        PlayerAnimator.SetBool(IsAttack, isAttackAble);
        PlayerAnimator.SetTrigger(ComboAttack);
    }

    public override void UpdateState()
    {
        if (isAttackAble)
        {
            swordEffect.transform.position = effectPoint.position;
        }
    }

    public override void ExitState()
    {
        isAttackAble = false;
        PlayerAnimator.SetBool(IsAttack, isAttackAble);
        receiver.OnAnimationTriggerReceived -= OnTriggerAnim;
    }

    private const string ATP_COLLDER_ON = "Sword_Collider_ON";
    private const string ATP_COLLDER_OFF = "Sword_Collider_OFF";
    private const string ATP_ANIM_END = "Sword_End";
    
    
    private void OnTriggerAnim(string str)
    {
        switch (str)
        {
            case ATP_COLLDER_ON:
                SwordCollider.enabled = true;
                break;
            case ATP_COLLDER_OFF:
                SwordCollider.enabled = false;
                break;
            case ATP_ANIM_END:
                PlayerController.ChangeState<IdleState>();
                break;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        throw new NotImplementedException();
    }
}
